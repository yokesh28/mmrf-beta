ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", 
	orientation: 'h', 
	classname: 'ddsmoothmenu', 
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" 
})